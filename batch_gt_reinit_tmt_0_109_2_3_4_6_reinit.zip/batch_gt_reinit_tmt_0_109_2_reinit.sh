#!/bin/bash -v
# generate 2r ground truth for all TMT sequences
DB_ROOT_PATH="/home/abhineet/Secondary/Datasets"
GT_ROOT_PATH="/home/abhineet/Secondary/Datasets"

#-----------------------------------------------------------------------------------------# 
#------------------------------------------ TMT ------------------------------------------# 
#-----------------------------------------------------------------------------------------# 

N_SEQ=109
ACTOR_ID=0
SEQ_ID=0
while [  $SEQ_ID -lt $N_SEQ ]; do
	python generateReinitGTByOptimization.py actor_id $ACTOR_ID seq_id $SEQ_ID show_img 0 db_root_dir $DB_ROOT_PATH gt_root_dir $GT_ROOT_PATH generate_trans 1 init_frame_id 0 end_frame_id -1
	let SEQ_ID=SEQ_ID+1 
done
